package FinalHackathon;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Home extends Browser
{
	@Test(priority=1)		//Clicking on Living menu
	public void clickLiving() throws InterruptedException
	{
		Locators.clickLiving().click();
		Thread.sleep(3000);
	}
	@Test(priority=2)		//Clicking on sub-menu item bookshelves  
	public void clickBookshelves() throws InterruptedException 
	{	
		Locators.clickBookshelves().click();
		Thread.sleep(3000);
	}
	@Test(priority=3)		//Closing the pop-up ad
	public void closeAdd() throws InterruptedException {
		Locators.closeAdd().click();
		Thread.sleep(3000);
	}
	@Test(priority=4)		//Click on exclude the out of stock option 
	public void clickStock() throws InterruptedException {
		
		Locators.clickStock().click();
		Thread.sleep(2000);
	}
	@Test(priority=5)		//Clicking on storage 
	public void clickStorage() throws InterruptedException {
		
		Locators.clickStorage().click();
		Thread.sleep(2000);
	}
	@Test(priority=6)		//Clicking on open from storage
	public void clickOpen() throws InterruptedException {
		
		Locators.clickOpen().click();
		Thread.sleep(2000);
	}
	@Test(priority=7)		//Clicking on Price and adjusting with to below 15000
	public void clickPrice() throws InterruptedException {
		Actions action=new Actions(driver);
		Thread.sleep(3000);
		//find the price dropdown
		WebElement element=Locators.clickPrice();
		action.moveToElement(element)
				.click()
				.perform();
		//select the right dragdown button from the price dropdown
				WebElement elem=Locators.selectRightDbutton();
				//drag it to the range 15000
				action.dragAndDropBy(elem, -243, 0)
				.perform();
	}
	@Test(priority=8)		//Printing 3 bookshelves along with name and price
	public void printBookSelves() throws InterruptedException, IOException{
		Thread.sleep(3000);
		//Declaring a list name l 
		List<String> l=new ArrayList<String>();
		List<String> l1=new ArrayList<String>();
		//Declaring a list name g
		List<String> g=new ArrayList<String>();
		List<String> g1=new ArrayList<String>();
		//Storing the new arrival items name in the item list 
		List<WebElement> item= Locators.selectNewArrivalItemsName();
		for(WebElement i:item)
		{
			l.add(i.getText());
		}
		//Storing the new arrival items price in the price list
		List<WebElement> price= Locators.selectNewArrivalItemsPrice();
		for(WebElement e:price)
		{
			String iprice=e.getText();
			g.add(iprice);		
		}
		System.out.println("---The 3 Bookshelves with prices---");
		for(int i=0;i<3;i++)
		{
			System.out.println(l.get(i));//printing the name
			l1.add(l.get(i));
			System.out.println(g.get(i));//printing the price
			g1.add(g.get(i));
		}
		XSSFRow row1 = s2.createRow(0);
        XSSFCell cell1 = row1.createCell(0);
        cell1.setCellValue("3 Bookshelves with Name");
        XSSFRow row2 = s2.getRow(0);
        XSSFCell cell2 = row2.createCell(1);
        cell2.setCellValue("3 Bookshelves with Price");
		int rowNum = 1;
        for (String line : l1) {
            XSSFRow row = s2.createRow(rowNum++);
            XSSFCell cell = row.createCell(0);
            cell.setCellValue(line);
        }
        int rowNum1 = 1;
        for (String line : g1) {
            XSSFRow row = s2.getRow(rowNum1++);
            XSSFCell cell = row.createCell(1);
            cell.setCellValue(line);
        }

	}
	@Test(priority=9)		//Click on trending menu
	public void clickTrendingButton() throws InterruptedException {
	
		Locators.clickTrendingButton().click();
		Thread.sleep(2000);
	}
	@Test(priority=10)		//Printing the sub-menu items
	public void printSubItems() throws InterruptedException{
		List<WebElement> check=Locators.checkMenuItem();
		for(WebElement c:check)
		{
			if(!c.getText().equalsIgnoreCase("Being-At-home"))
			{
				break;
			}
		}
		System.out.println("\n---Being-At-home is not present in the Collections Menu---");
		System.out.println("---Thus taking New Arrivals sub-items under consideration---");
		System.out.println("\n---All the sub-items under New Arrivals---");
		List<WebElement> items=Locators.selectNewArrivalItems();
		List<String> l=new ArrayList<String>();
		for(WebElement w:items)
		{
			System.out.println(w.getText());//printing the items in the new arrival section
			l.add(w.getText());
		}
		XSSFRow row1 = s3.createRow(0);
        XSSFCell cell1 = row1.createCell(0);
        cell1.setCellValue("Sub Menu-Items");
		int rowNum2 = 1;
        for (String line : l) {
            XSSFRow row = s3.createRow(rowNum2++);
            XSSFCell cell = row.createCell(0);
            cell.setCellValue(line);
       }
		Thread.sleep(2000);
	}
	@Test(priority=11)		//click on gift cards
	public void clickGiftCard() throws InterruptedException {
	
		Locators.clickGiftCard().click();
		Thread.sleep(2000);
	}
	@Test(priority=12)		//click birthday/anniversary option using mouse action
	public void clickBirthdayAnniversary() throws InterruptedException {

		Actions action=new Actions(driver);
		Thread.sleep(3000);
		WebElement elemn= Locators.clickBirthdayAnniversary();
		action.moveToElement(elemn)
		.click()
		.perform();
		Thread.sleep(2000);
	}
	@Test(priority=13)		//click on 10000 button
	public void clickOn10000() throws InterruptedException {
	
		Locators.clickOn10000().click();
		Thread.sleep(2000);
	}
	@Test(priority=14)		//click on next button
	public void clickOnNext() throws InterruptedException {

		Locators.clickOnNextButton().click();
		Thread.sleep(2000);
	}
	@Test(priority=15)		//enter recipients name
	public void recipentsName() 
	{	
		Locators.recipentsName().sendKeys(r1.getCell(0).getStringCellValue());
		
	}
	@Test(priority=16)		//enter senders name
	public void myName() {
		
		Locators.myName().sendKeys(r1.getCell(3).getStringCellValue());
	}
	@Test(priority=17)		//enter recipients email
	public void recipentsEmail() {
		
		Locators.recipentsEmail().sendKeys(r1.getCell(1).getStringCellValue());
	}
	@Test(priority=18)		//enter senders email
	public void myEmail() {
		
		Locators.myEmail().sendKeys(r1.getCell(4).getStringCellValue());
	}
	@Test(priority=19)		//enter recipients mobile number
	public void recipentsMobileNo() {
	
		Locators.recipentsMobileNo().sendKeys(r1.getCell(2).getStringCellValue());
	}
	@Test(priority=20)		//enter senders mobile number
	public void myMobileNo() {
	
		Locators.myMobileNo().sendKeys(r1.getCell(5).getStringCellValue());
	}
	@Test(priority=21)		//enter senders address
	public void myAddress() {
		
		Locators.myAddress().sendKeys(r1.getCell(6).getStringCellValue());
	}
	@Test(priority=22)		//enter sender pincode
	public void myPincode() throws InterruptedException {
		
		int pincode=(int)r1.getCell(7).getNumericCellValue();
		String p=Integer.toString(pincode);
		Locators.myPincode().sendKeys(p);
		Thread.sleep(1000);
	}
	@Test(priority=23)		//click on confirm button
	public void clickConfirmButton() {
		
		Locators.clickConfirmButton().click();
	}
	@Test(priority=24)		//Click to pay and proceed button
	public void clickProceedToPay()throws InterruptedException {
	
		Locators.clickProceedToPayButton().click();
		Thread.sleep(2000);
	}
	@Test(priority=25)		//take screenshot of the error message and saving it locally
	public void takeScreenShot()throws InterruptedException, IOException {

		System.out.println("\n---Taking Screenshot---");
		File screenshot= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File("C:\\Users\\2264549\\eclipse-workspace\\2264549\\src\\test\\java\\FinalHackathon\\ScreenShot\\screenshot.png"));
		Thread.sleep(1000);
	}
	@Test(priority=26)		//printing the error message into the console
	public void printErrorMessage() throws IOException {
	
		System.out.println("---The error message displayed is---");
		List<WebElement> error= Locators.screenShot();
		List<String> l=new ArrayList<String>();
		for(WebElement e:error)
		{
			System.out.println(e.getText());
			l.add(e.getText());
		}
		XSSFRow row1 = s4.createRow(0);
        XSSFCell cell1 = row1.createCell(0);
        cell1.setCellValue("Error Message");
		int rowNum = 1;
        for (WebElement line : error) {
            XSSFRow row = s4.createRow(rowNum++);
            XSSFCell cell = row.createCell(0);
            cell.setCellValue(line.getText());
       }
        w2.write(fout);
	}
	
	
	//Invoking all the methods
	public static void main(String[] args)  throws Exception
	{
		try
		{
			Home obj = new Home();
			setDriver();
			getUrl();
			setWorkbook();
			writeWorkBook();
			obj.clickLiving();
			obj.clickBookshelves();
			obj.closeAdd();
			obj.clickStock();
			obj.clickStorage();
			obj.clickOpen();
			obj.clickPrice();
			obj.printBookSelves();
			obj.clickTrendingButton();
			obj.printSubItems();
			obj.clickGiftCard();
			obj.clickBirthdayAnniversary();
			obj.clickOn10000();
			obj.clickOnNext();
			obj.recipentsName();
			obj.myName();
			obj.recipentsEmail();
			obj.myEmail();
			obj.recipentsMobileNo();
			obj.myMobileNo();
			obj.myAddress();
			obj.myPincode();
			obj.clickConfirmButton();
			obj.clickProceedToPay();
			obj.takeScreenShot();
			obj.printErrorMessage();
			closeBrowser();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

	

	
	
