package FinalHackathon;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Browser 
{
	public static WebDriver driver;
	public static FileInputStream fin1,fin2;
	public static FileOutputStream fout;
	public static XSSFWorkbook w1,w2;
	public static XSSFSheet s1,s2,s3,s4;
	public static XSSFRow r1;
	
	@BeforeSuite     //Driver Setup method
	public static WebDriver setDriver() {
		Scanner sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your choice of browser : Chrome or Edge");
		String str=sc.nextLine();
		if(str.equalsIgnoreCase("chrome")) {
			//WebDriverManager.chromedriver().setup();
			System.setProperty("webdriver.chrome.driver","C:\\Users\\2264549\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			driver= new ChromeDriver();
			return driver;
		}
		else if(str.equalsIgnoreCase("edge"))
		{
			//WebDriverManager.edgedriver().setup();
			driver= new EdgeDriver();
			return driver;
		}else
		{
			System.out.println("---Wrong Choice---");
			continue;
		}
		}
	}
	
	@BeforeClass		//Browser open method
	public static void getUrl() throws Exception
	{
			driver.get("https://www.urbanladder.com/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	
	@BeforeClass		//Workbook Setup method for read data
	public static void setWorkbook() throws IOException
	{
		fin1=new FileInputStream("C:\\Users\\2264549\\eclipse-workspace\\2264549\\src\\test\\java\\FinalHackathon\\read.xlsx");	
		w1=new XSSFWorkbook(fin1);
		s1=w1.getSheetAt(0);
		r1=s1.getRow(1);
	}
	
	@BeforeClass		//Workbook Setup method for write data
	public static void writeWorkBook() throws IOException
	{
		fin2=new FileInputStream("C:\\Users\\2264549\\eclipse-workspace\\2264549\\src\\test\\java\\FinalHackathon\\write.xlsx");	
		w2=new XSSFWorkbook(fin2);
		s2=w2.getSheet("Sheet1");
		s3=w2.getSheet("Sheet2");
		s4=w2.getSheet("Sheet3");
		fout= new FileOutputStream("C:\\Users\\2264549\\eclipse-workspace\\2264549\\src\\test\\java\\FinalHackathon\\write.xlsx");
	}
	
	//Close the browser
	@AfterClass			
	public static void closeBrowser() 
	{
		driver.quit();
	}
}
