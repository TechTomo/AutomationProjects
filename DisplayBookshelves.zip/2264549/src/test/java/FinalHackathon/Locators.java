package FinalHackathon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

//Class which contains all the locators used in performing the functionalities 
public class Locators extends Browser
{
	public static WebElement clickLiving() {
	
		return driver.findElement(By.xpath("//li[@class='topnav_item livingunit']"));
	}

	public static WebElement clickBookshelves() {
		
		return driver.findElement(By.xpath("//li[@class='subnav_item 1698']"));
	}

	public static WebElement closeAdd() {
		
		return driver.findElement(By.xpath("//a[@class='close-reveal-modal hide-mobile']"));
	}

	public static WebElement clickStock() {
		
		return driver.findElement(By.id("filters_availability_In_Stock_Only"));
	}
	public static WebElement clickStorage() {
	
		return driver.findElement(By.xpath("//li[@class='item' and @data-group='storage type']"));
	}
	public static WebElement clickOpen() {
		
		return driver.findElement(By.id("filters_storage_type_Open"));	
	}
	public static WebElement clickPrice() {

		return driver.findElement(By.xpath("//li[@class='item' and @data-group='price']"));
		
	}
	public static WebElement selectRightDbutton() {
	
		return driver.findElement(By.cssSelector("div.noUi-handle.noUi-handle-upper"));
		
	}
	public static List<WebElement> selectNewArrivalItemsName() {
	
		return driver.findElements(By.cssSelector("span.name"));	
	}
	public static List<WebElement> checkMenuItem() {
		
		return driver.findElements(By.xpath("//div[@class='taxontype']"));
	}
	public static List<WebElement> selectNewArrivalItemsPrice() {
		
		return driver.findElements(By.xpath("//div[@class='price-number']//child::span"));
	}
	public static WebElement clickTrendingButton() {
	
		return driver.findElement(By.xpath("//li[@class='topnav_item trendingunit']"));	
	}
	public static WebElement clickNewArrivalButton() {
		
		return driver.findElement(By.xpath("//a[text()='New Arrivals']"));	
	}
	public static List<WebElement> selectNewArrivalItems() {
		
		return driver.findElements(By.xpath("(//ul[@class='taxonslist'])[34]"));
	}
	public static WebElement clickGiftCard() {
		
		return driver.findElement(By.xpath("//a[@class='featuredLinksBar__link' and text()=' Gift Cards ']"));	
	}
	public static WebElement clickBirthdayAnniversary() {
	
		return driver.findElement(By.xpath("(//li[@class='_11b4v'])[3]"));	
	}
	public static WebElement clickOn10000() {
	
		return driver.findElement(By.xpath("(//button[@class='HuPJS'])[3]"));	
	}
	public static WebElement clickOnNextButton() {
		
		return driver.findElement(By.xpath("//button[@class='_1IFIb _1fVSi action-button _1gIUf _1XfDi']"));	
	}
	public static WebElement recipentsName() {
		
		return driver.findElement(By.id("ip_4036288348"));
	}
	public static WebElement myName() {
		
		return driver.findElement(By.id("ip_1082986083"));
	}
	public static WebElement recipentsEmail() {
	
		return driver.findElement(By.id("ip_137656023"));
	}
	public static WebElement myEmail() {
		
		return driver.findElement(By.id("ip_4081352456"));
	}
	public static WebElement recipentsMobileNo() {
	
		return driver.findElement(By.id("ip_3177473671"));
	}
	public static WebElement myMobileNo() {
	
		return driver.findElement(By.id("ip_2121573464"));
	}
	public static WebElement myAddress() {
		
		return driver.findElement(By.id("ip_2194351474"));
	}
	public static WebElement myPincode() {
		
		return driver.findElement(By.id("ip_567727260"));
	}
	public static WebElement clickConfirmButton() {

		return driver.findElement(By.xpath("//button[@class='_3Hxyv _1fVSi action-button _1gIUf _1XfDi']"));
	}
	public static WebElement clickProceedToPayButton() {

		return driver.findElement(By.xpath("//button[@class='_3NxK9 _1fVSi action-button _1gIUf _1XfDi']"));
	}
	public static List<WebElement> screenShot() {
		return driver.findElements(By.cssSelector("ul._6SsU6"));
	}

	
	
	

	
	
	
}
