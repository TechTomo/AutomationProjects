package Tilakhackathonprojectfinal;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Browser {
	public static WebDriver driver;
	@BeforeTest
	public static WebDriver setDriver() {
		driver = new EdgeDriver();
		return driver;		
	}
	@Test(priority=0)
	public static void getUrl() throws Exception{
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@AfterTest
	//close browser
    public static void closeBrowser()  {
    	driver.quit();
    }
}
