package Tilakhackathonprojectfinal;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Home extends Browser{
	@Test(priority=1)
	private void iFrameadclose() throws InterruptedException {
		// TODO Auto-generated method stub
		 driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@name='notification-frame-b8a69a19']")));
	     Thread.sleep(3000);
         driver.findElement(By.xpath("//a[@class='close']")).click();
	     
	}
	@Test(priority=2)
	private void switchTomainPage() {
		// TODO Auto-generated method stub
		driver.switchTo().parentFrame();
	}
	@Test(priority=3)
	public void cabClick() {
		Locators.cabClick().click();
	}
	@Test(priority=4)
	public void pickup() {
		Locators.pickUp().click();
	}
	@Test(priority=5)
	public void delhi() throws InterruptedException {
		Locators.delhi().click();
		//Thread.sleep(2000);
	}
	@Test(priority=6)
	public void destination() throws InterruptedException {
		Locators.destination().click();
		Thread.sleep(2000);
	}
	@Test(priority=7)
	public void destinationTextBox() throws InterruptedException, IOException {
		String filePath = ".//ExcelFile//Manali.xlsx";
		FileInputStream fis = new FileInputStream(filePath);
	    XSSFWorkbook workbook = new XSSFWorkbook(fis);
	    XSSFSheet sheet = workbook.getSheet("Manali");
	    String cellvalue = sheet.getRow(0).getCell(0).getStringCellValue();
	    String cellvalue1 = sheet.getRow(0).getCell(1).getStringCellValue();
	    String cellvalue2 = sheet.getRow(0).getCell(2).getStringCellValue();
	    Locators.destinationTextBox().sendKeys(cellvalue);
		Thread.sleep(4000);
	}
	@Test(priority=8)
	public void manali() {
		Locators.manali().click();
	}
	@Test(priority=9)
	public void departure() {
		Locators.departure().click();
	}
	@Test(priority=10)
	public void nextarrow() throws InterruptedException {
		Locators.nextarrow().click();
		Thread.sleep(2000);
		Locators.nextarrow().click();
	}
	@Test(priority=11)
	public void departureDate() {
		Locators.departureDate().click();
	}
	@Test(priority=12)
	public void searchbtn() throws InterruptedException {
		Locators.searchbtn().click();
		Thread.sleep(4000);
	}
	@Test(priority=13)
	public void suv() throws InterruptedException {
		Locators.suv().click();
		Thread.sleep(3000);
	}
	@Test(priority=14)
	public void ExcelWork() throws IOException {
		String vehicle1= driver.findElement(By.xpath("//*[@id=\"List\"]/div[1]/div/div[2]/div[1]/div[1]/span[1]")).getText();
		String price1 = driver.findElement(By.xpath("//*[@id=\"List\"]/div[1]/div/div[3]/div/div[2]/div/p[1]")).getText();
//		File file = new File("C:\\Users\\2264579\\eclipse-workspace\\Tilakhhackathonprojectfinal.zip\\Tilakhhackathonprojectfinal\\ExcelFile\\Vehicleprice.xlsx");
//	    FileOutputStream fos = new FileOutputStream(file);
//		XSSFWorkbook workbook1 = new XSSFWorkbook();
//	    XSSFSheet sheet1 = workbook1.createSheet("Sheet1");
//	    sheet1.createRow(0);
//	    sheet1.getRow(0).createCell(0).setCellValue(vehicle1);
//	    sheet1.getRow(0).createCell(1).setCellValue(price1);
		System.out.println(vehicle1);
		System.out.println(price1);
	}
	
	@Test(priority=15)
	public void hotel() {
		Locators.hotel().click();
	}
	@Test(priority=16)
	public void roomsandguest() {
		Locators.roomsandguest().click();
	}
	@Test(priority=17)
	public void noofadults() {
		Locators.noofadults().click();
	}
	@Test(priority=18)
	public void maxnumberofadults() {
		Locators.maxnumberofadults().click();
	}
	@Test(priority=19)
	public void printnoofadults() throws InterruptedException {
		String numberofadults = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div/span")).getText();
		System.out.println(numberofadults);
		Thread.sleep(3000);
	}
	@Test(priority=20)
	public void apply() throws InterruptedException {
		Locators.apply().click();
		Thread.sleep(3000);
	}
	
	




}
