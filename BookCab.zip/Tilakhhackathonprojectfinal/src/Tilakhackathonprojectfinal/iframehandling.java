package Tilakhackathonprojectfinal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class iframehandling extends Browser{
	//focussing on frame
	public static WebElement iFrameadclose() throws InterruptedException {
	     driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@name='notification-frame-b8a69a19']")));
	     Thread.sleep(3000);
         driver.findElement(By.xpath("//a[@class='close']")).click();
	     return iFrameadclose();
	}
	
	//focusing on main page
	
	public static WebElement switchTomainPage() {
		driver.switchTo().parentFrame();
		return switchTomainPage();
	}
	

}
