package Tilakhackathonprojectfinal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Locators extends Browser{
	
	public static WebElement cabClick() {
		return driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[2]/div/div/nav/ul/li[7]/div/a/span[1]"));		
	}
	
	public static WebElement pickUp() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div/div[1]/label/span"));
	}
	
	public static WebElement delhi() {
		return driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-1\"]/div/p/span"));
	}
	
	public static WebElement destination() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div/div[2]/label/span"));
	}
	
	public static WebElement destinationTextBox() {
		return driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/input"));
	}
	
	public static WebElement manali() {
		return driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-0\"]/div/p/span"));
	}
	
	public static WebElement departure() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/label/span"));
	}
	
	public static WebElement nextarrow() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[1]/span[2]"));
	}
	
	public static WebElement departureDate() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[4]/div[2]"));
	}
	
	public static WebElement searchbtn() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/p/a"));
	}
	
	public static WebElement suv() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[2]/div[1]/div/div[2]/div[2]/span/label"));
	}
	
	public static WebElement hotel() {
		return driver.findElement(By.xpath("//a[@href='https://www.makemytrip.com/hotels/']"));
	}
	
	public static WebElement roomsandguest() {
		return driver.findElement(By.xpath("//label[@for='guest']"));
	}
	
	public static WebElement noofadults() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div"));
	}
	
	public static WebElement maxnumberofadults() {
		return driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/ul/li[40]"));
	}
	
	public static WebElement apply() {
		return driver.findElement(By.xpath("//button[@data-cy='RoomsGuestsNew_327']"));
	}

}
