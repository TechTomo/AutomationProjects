package CalculateTripCost;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TripAutomation {
	public static WebDriver driver;
	public static XSSFRow r1;
	public static XSSFSheet s1,s2,s3;
	public static FileOutputStream fout2;
	public static XSSFWorkbook w2;
	
	@BeforeClass
	public static void setDriver() throws InterruptedException, IOException {
		WebDriverManager.chromedriver().arch64().setup();
		driver = new ChromeDriver(); 
		String baseUrl = "https://www.tripadvisor.in/";

	     driver.manage().deleteAllCookies();
		 driver.get(baseUrl);
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		 driver.manage().deleteAllCookies();
		 FileInputStream fin=new FileInputStream("C:\\Users\\leora\\eclipse-workspace\\CalculateTripCost\\src\\test\\java\\CalculateTripCost\\read.xlsx");
		 FileInputStream fout1=new FileInputStream("C:\\Users\\leora\\eclipse-workspace\\CalculateTripCost\\src\\test\\java\\CalculateTripCost\\write.xlsx");
		 XSSFWorkbook w1=new XSSFWorkbook(fin);
		 w2=new XSSFWorkbook(fout1);
		 s1=w1.getSheet("Sheet1");
		 s2=w2.getSheet("Sheet1");
		 s3=w2.getSheet("Sheet2");
		 r1=s1.getRow(1);
		 driver.findElement(By.xpath("//span[text()='Holiday Homes']")).click();
		 XSSFCell c=r1.getCell(0);
		 driver.findElement(By.xpath("(//input[@class='qjfqs _G B- z _J Cj R0'])[3]")).sendKeys(c.getStringCellValue());
		 fout2=new FileOutputStream("C:\\Users\\leora\\eclipse-workspace\\CalculateTripCost\\src\\test\\java\\CalculateTripCost\\write.xlsx");
		 Thread.sleep(2000);
	}
	@Test(priority=1)
	public void datePicker() throws InterruptedException {

		driver.findElement(By.xpath("(//a[@class='GzJDZ w z _S _F Wc Wh Q B- _G'])[1]")).click();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		driver.findElement(By.xpath("//button[@class='duUGc z B2 Z BC _S q o W f u G mnpxG F1 wSSLS']")).click();
		
		JavascriptExecutor j = (JavascriptExecutor) driver;
		WebElement l1=driver.findElement(By.xpath("(//div[@class='loUIs f c z _S V wSSLS rzEGW jsRVM'])[2]"));
		j.executeScript("arguments[0].click();", l1);
		WebElement l2=driver.findElement(By.xpath("(//div[@class='loUIs f c z _S V wSSLS rzEGW wqXjm'])[3]"));
		j.executeScript("arguments[0].click();", l2);
		Thread.sleep(3000);
	}
	@Test(priority=2)
	public void travellerPersonChoose() throws InterruptedException {
		
		 driver.findElement(By.xpath("//button[@class='duUGc z B2 Z BC _S q o W f u G wSSLS']")).click();
	     driver.findElement(By.xpath("(//button[@class='MnqWg S5 _S _H _W u j'])[2]")).click();
	     driver.findElement(By.xpath("(//button[@class='MnqWg S5 _S _H _W u j'])[2]")).click();
	     JavascriptExecutor j = (JavascriptExecutor) driver;
	     WebElement l=driver.findElement(By.xpath("(//button[@class='rmyCe _G B- z _S c Wc wSSLS jWkoZ sOtnj'])[2]"));
	     j.executeScript("arguments[0].click();", l);
	     Thread.sleep(3000);
	}
	@Test(priority=3)
	public void travellerRating() throws InterruptedException {
		
		driver.findElement(By.xpath("//button[@class='OKHdJ z Pc PQ Pp PD W _S Gn Z B2 BF _M PQFNM wSSLS']")).click();
		driver.findElement(By.xpath("//span[@id='menu-item-TRAVELERRATINGHIGH']")).click();
		Thread.sleep(3000);
	}
	@Test(priority=4)
	public void elevatorAccess() throws InterruptedException {
		
		driver.findElement(By.xpath("(//button[@class='UikNM _G B- _S _T c G_ P0 wSSLS TXrCr'])[1]")).click();
		WebElement e=driver.findElement(By.xpath("//input[@id='amenities.27']"));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", e);
		driver.findElement(By.xpath("(//button[@class='rmyCe _G B- z _S c Wc wSSLS jWkoZ sOtnj'])[2]")).click();
		Thread.sleep(3000);
	}
	@Test(priority=5)
	public void printingHotelDetails() throws InterruptedException {
		 int c1=0,c2=0;
	     System.out.println("---Three Hotel Names---");
	     List<WebElement> items=driver.findElements(By.xpath("//a[@class='ToVyw b S7 W o q']"));
	     if(items.isEmpty())
	     {
	    	 items=driver.findElements(By.xpath("//div[@class='MndtX W o q']"));
	     }
	     XSSFRow row1=s2.createRow(0);
	     XSSFCell coll1=row1.createCell(0);
	     coll1.setCellValue("Hotel Names");
	     XSSFRow row2=s2.getRow(0);
	     XSSFCell coll2=row2.createCell(1);
	     coll2.setCellValue("Hotel Prices");
	     int row=1;
	     for(WebElement i:items)
	     {
	    	 if(c1==3)
	    		 break;
	    	System.out.println(i.getText());
	    	XSSFRow r1=s2.createRow(row++);
	    	XSSFCell col1=r1.createCell(0);
	    	col1.setCellValue(i.getText());
	    	 c1++;
	     }
	     row=1;
	     System.out.println("\n---Three Hotel Price---");
	     List<WebElement> price=driver.findElements(By.xpath("//div[@class='xTNVq']"));
	     if(price.isEmpty())
	     {
	    	 price=driver.findElements(By.xpath("//div[@class='yyeZp']"));
	     }
	     for(WebElement i:price)
	     {
	    	 if(c2==3)
	    		 break;
	    	System.out.println(i.getText());
	    	XSSFRow r2=s2.getRow(row++);
	    	XSSFCell col2=r2.createCell(1);
	    	col2.setCellValue(i.getText());
	    	c2++;
	     }
	     Thread.sleep(3000);
	}
	@Test(priority=6)
	public void enterInCruise() throws InterruptedException {
		
		driver.findElement(By.xpath("(//a[@class='EJavG c _S'])[7]")).click();
	     driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	     //click cruise line
		driver.findElement(By.xpath("//span[@class='biGQs _P eVqsT fOtGX'][1]")).click();
		//choose australis
		driver.findElement(By.xpath("//span[@id='menu-item-17391501']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='rmyCe _G B- z _S c Wc wSSLS w AeLHi sOtnj ymEbx']")).click();
		ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(newTb.get(1));
	    Thread.sleep(5000);
	}
	@Test(priority=7)
	public void cruiseDetails() throws InterruptedException, IOException {
		System.out.println("\n---Cruise Passenger Details---");
		XSSFRow row1=s3.createRow(0);
	     XSSFCell coll1=row1.createCell(0);
	     coll1.setCellValue("Cruise Passenger");
	     XSSFRow row2=s3.getRow(0);
	     XSSFCell coll2=row2.createCell(1);
	     coll2.setCellValue("Cruise Language");
	     int row=1;
	    List<WebElement> about=driver.findElements(By.xpath("//*[@class='szsLm']"));
	    for(WebElement i:about)
		{
			System.out.println(i.getText());
			XSSFRow r1=s3.createRow(row++);
	    	XSSFCell col1=r1.createCell(0);
	    	col1.setCellValue(i.getText());
		}
		row=1;
		System.out.println("\n---Cruise Languages Details---");
		List<WebElement> lang=driver.findElements(By.xpath("(//ul[@class='LojWi w S4'])[3]"));
		for(WebElement i:lang)
		{
			System.out.println(i.getText());
			XSSFRow r2=s3.getRow(row++);
	    	XSSFCell col2=r2.createCell(1);
	    	col2.setCellValue(i.getText());
		}
		w2.write(fout2);
	}
	@AfterClass
	public static void closeBrowser() 
	{
		driver.quit();
	}
	public static void main(String args[])throws Exception
	{
		TripAutomation obj=new TripAutomation();
		setDriver();
		obj.datePicker();
		obj.travellerPersonChoose();
		obj.travellerRating();
		obj.elevatorAccess();
		obj.printingHotelDetails();
		obj.enterInCruise();
		obj.cruiseDetails();
		closeBrowser();
	}
}
