package finalHackathon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Locators extends Browser    
{
	 
	//Click on Text box 
	public static WebElement clickTextBox() {
		return driver.findElement(By.xpath("//input[@type='text']"));
	}
	  
	//Selecting Beginner level
	public static WebElement selectBeg() {
		return driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/main/div[2]/div/div/div/div/div[1]/div/div[4]/div/div/div[1]/label/span/span/input"));
	}
	
	//Click Show More
	public static WebElement ShowMore() {
		return driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/div/div[1]/main/div[2]/div/div/div/div/div[1]/div/div[8]/div[2]/button"));
	}

	//Select English Language
	public static WebElement selectEnglish() {
		return driver.findElement(By.xpath("//div[@data-testid='English-false']"));
	}
	
	//Click on Apply
	public static WebElement Apply() {
		return driver.findElement(By.xpath("/html/body/div[8]/div[3]/div/div/div[2]/div[3]/button[1]/span"));
	}
	
	
	//Print name of courses 
	public static WebElement Name() {
//		WebElement name1=driver.findElement(By.xpath("//div[@class='_pu0m129']//following :: div[@data-test='banner-title-container']/h1"));
//		return name1;
//		
//	}
		WebElement name2= driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/main/section[2]/div/div/div[1]/div[1]/section/h1"));
		return name2;
		
	}
	
	//Print rating of courses
	public static WebElement Rating() {
//		WebElement rat1= driver.findElement(By.xpath("//div[@class='_1srkxe1s XDPRating']//following :: span[@data-test='number-star-rating'][1]"));
//		return rat1;
//		}
		WebElement rat2 = driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/main/section[2]/div/div/div[2]/div/div/section/div[2]/div[1]/div[1]"));
		return rat2;
		} 
	
	//Printing time of courses
	public static WebElement Time() {
//		WebElement time1 =  driver.findElement(By.xpath("/html/body/div[2]/div/div/main/div/div[2]/div/div/div/div[2]/div[1]/div/div[5]/div[2]/div[1]/span"));
//		return time1;
//	}
		WebElement time2 = driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/main/section[2]/div/div/div[2]/div/div/section/div[2]/div[3]/div[1]"));
		return time2;
	}
	
	
	//Click on Explore Drop down
	public static WebElement explore() {
		return driver.findElement(By.xpath("//*[@id=\"MegamenuWrapperDiv\"]/div/div/button/span"));
	}
	
	//Click on learning language
	public static WebElement Learning() {
		return driver.findElement(By.xpath("//*[@id=\"language-learning~menu-item\"]/span[1]"));
	}
	
	//Click on free
	public static WebElement Free() {
		return driver.findElement(By.xpath("//*[@id=\"MegamenuWrapperDiv\"]/div/div/div/nav/div/div/div[2]/div[10]/div/section/div/div[2]/div[2]/div[1]/ul/li[1]/div/a"));
	}
	
	//Print Result
	public static WebElement results() {
		WebElement result= driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/div/div[1]/main/div[2]/div/div/div/div/div[2]/div[1]/h1/div"));
		return result;
	}
	
	//Total Language
	public static WebElement total() {
		return driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/div/div[1]/main/div[2]/div/div/div/div/div[1]/div/div[8]/div[2]/button"));
	}
	 
	//Language count 
	public static int Totalcount()
	{	
		int c=0;
		List<WebElement> l = driver.findElements(By.xpath("//div[@class='css-ib4aph']"));
		for(WebElement w:l) { 
			w.getText();  
			c++; 
		}
		return c; 
	}
	
	//close button
	public static WebElement closing() {
		return driver.findElement(By.xpath("/html/body/div[8]/div[3]/div/div/div[1]/button/span"));
	}
	//Go to Home
	public static WebElement home() {
		return driver.findElement(By.xpath("//div[@class='css-19qryfx']"));
	}
	
	//Click on for Enterprises
	public static WebElement enter() {
		return driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div/div/div/div/div[5]/ul/li[10]/a"));
	}
	
	//Click on contact sales
	public static WebElement contacts() {
		return driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/div/div[1]/div/header/div[2]/div[1]/div/div/div/div[3]/div/a/span"));
	}
	
	//Entering first name
	public static WebElement name() {
		return driver.findElement(By.xpath("//*[@id=\"FirstName\"]"));
	}
	
	//entering last name
	public static WebElement last() { 
		return driver.findElement(By.xpath("//*[@id=\"LastName\"]"));
	}
	
	//entering email 
	public static WebElement email() {
		return driver.findElement(By.xpath("//*[@id=\"Email\"]"));
	}
	
	//submit
	public static WebElement submit() {
		return driver.findElement(By.xpath("//*[@id=\"mktoForm_2666\"]/div[53]/span/button"));
	}
	
	//error message print
	public static WebElement message() {
		return driver.findElement(By.xpath("//*[@id=\"ValidMsgEmail\"]"));
	}

	
	
}
