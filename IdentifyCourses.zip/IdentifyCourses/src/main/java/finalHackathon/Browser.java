package finalHackathon;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeClass;
	
public class Browser 
{    
	public static WebDriver driver;
	public static FileInputStream fin1;
	public static FileInputStream fin2;
	public static FileOutputStream fout;
	public static XSSFWorkbook w1;
	public static XSSFWorkbook w2;
	public static XSSFSheet s1;
	public static XSSFSheet s2;
	public static XSSFRow r1;
	public static XSSFRow r2;
	
	@BeforeSuite
	public WebDriver setDriver() {
//		Scanner sc = new Scanner();
//		
//		WebDriverManager.chromedriver().setup();
//		driver= new ChromeDriver();
		driver = new EdgeDriver();
		
		return driver; 
	}
 
	 @BeforeClass
	public void getUrl() {
		driver.get("https://www.coursera.org/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	 //
	@BeforeClass
	public void setWorkbook() throws IOException {
		fin1 = new FileInputStream("C:\\Users\\2264616\\eclipse-workspace\\Aniket\\src\\main\\java\\finalHackathon\\Read.xlsx");
		w1 = new XSSFWorkbook(fin1);
		s1=w1.getSheetAt(0);
		r1=s1.getRow(1);
		fout=new FileOutputStream("C:\\Users\\2264616\\eclipse-workspace\\Aniket\\src\\main\\java\\finalHackathon\\Book2.xlsx");
		}
	
	@AfterClass
	//Close the Browser 
	public void closeBrowser() 
	{
		driver.quit();
	}
}
