package finalHackathon;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Home extends Browser {
	 
	@Test(priority=0)
	// Entering Web Development in text box and click enter
	public void TextBox() { 
		WebElement ele= Locators.clickTextBox();
		ele.sendKeys(r1.getCell(0).getStringCellValue()); 
		Actions action = new Actions(driver); 
		action.moveToElement(ele).click().sendKeys(Keys.ENTER).perform();
	}
	@Test(priority=1) 
	//Selecting Beginner Level and English Language
	 public void selectBeginner() { 
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("window.scrollBy(0,700)");
		Locators.selectBeg().click();
	}
	@Test (priority=2) 
	 //Click Show More option
	 public void clickShowMore() {
		 JavascriptExecutor j = (JavascriptExecutor) driver;
		 j.executeScript("window.scrollBy(0,1100)"); 
		 Locators.ShowMore().click();
	 }
	@Test(priority=3)
	 //Selecting English Language
	 public void clickEnglish() {
		 Locators.selectEnglish().click();
		 Locators.Apply().click();
		 JavascriptExecutor j = (JavascriptExecutor) driver;
		 j.executeScript("window.scrollBy(0,-1600)");
	 }
	  
	@Test(priority=4)
	 //Printing details of first two courses 
	 public void Courses() {
		 for(int i=1;i<=2;i++) {
			driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/main/div[2]/div/div/div/div/div[2]/ul/li["+i+"]")).click();
			ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(newTb.get(1));		                     
			String n= Locators.Name().getText();
			System.out.println("("+i+") Course Name :" +n);
			String r = Locators.Rating().getText();  
			System.out.println("Ratings : "+r );
			String t = Locators.Time().getText();  
			System.out.println("Time : "+t );
			driver.close();
			ArrayList<String> Tb = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(Tb.get(0));
		 }
	 }
	@Test(priority=5)
	 //Clicking on Learning Language
	 public void FreeLearningLanguages() {
		 Locators.explore().click();
		 Locators.Learning().click();
		 Locators.Free().click();
	 } 
	@Test(priority=6)
	 //Printing Result
	 public void Result() {
		 String x= Locators.results().getText();
		 JavascriptExecutor j = (JavascriptExecutor) driver;
		 j.executeScript("window.scrollBy(0,600)");
		 System.out.println("Total results :" + x);
	 }
	@Test(priority=7)
	 // Total Count 
	public void Total() {
		Locators.total().click();
		int ct=Locators.Totalcount();
		System.out.println("Total Languages : "+ct);
		Locators.closing().click();
	}
	@Test(priority=8) 
	//Go to home page
	public void Homepage() throws InterruptedException { 
		Thread.sleep(3000);
		Locators.home().click();
	}
	@Test(priority=9)
	//Click on for Enterprises
	public void Enter() {
		Locators.enter().click();
	}
	@Test(priority=10)
	//Click on contact sales 
	public void Contact() {
		Locators.contacts().click();
	}
	@Test(priority=11)
	//Entering first name
	public void Name() {
		Locators.name().sendKeys(r1.getCell(1).getStringCellValue());
	}
	@Test(priority=12)
	//Entering last name
	public void Last() {
		Locators.last().sendKeys(r1.getCell(2).getStringCellValue());
	}
	@Test(priority=13)
	//Entering email
	public void Email() {
		Locators.email().sendKeys(r1.getCell(3).getStringCellValue());
	}
	@Test(priority=14)
	//Submit
	public void Submit() throws InterruptedException {
		Locators.submit().click();
		String msg = Locators.message().getText();
		System.out.println("Error Message : "+msg);
		Thread.sleep(3000); 
	} 
	@Test(priority=15)
	//Capture Error message 
	public void ss() throws IOException {
		File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file,new File("C:\\Users\\2264616\\eclipse-workspace\\Aniket\\src\\main\\java\\Screenshot\\ErrorMessage.png"));
		
	}
	
}