package FindingHospitals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

 

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

 

public class FindingHospitals extends DriverSetup{

    @Test(priority=1)
    public void getUrl() throws Exception
    {
        //Opening the website
        driver.get("https://www.practo.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
        driver.manage().deleteAllCookies();
        fin=new FileInputStream("C:\\Users\\leora\\eclipse-workspace\\FindingHospitals\\src\\test\\java\\FindingHospitals\\read.xlsx");
        fout1=new FileInputStream("C:\\Users\\leora\\eclipse-workspace\\FindingHospitals\\src\\test\\java\\FindingHospitals\\write.xlsx");
        w=new XSSFWorkbook(fin);
        w1=new XSSFWorkbook(fout1);
        s1=w.getSheet("Sheet1");
        s2=w.getSheet("Sheet2");
        s3=w1.getSheet("Sheet1");
        s4=w1.getSheet("Sheet2");
        fout2=new FileOutputStream("C:\\Users\\leora\\eclipse-workspace\\FindingHospitals\\src\\test\\java\\FindingHospitals\\write.xlsx");
    }

    @Test(priority=2)
    public void gotoBangaloreHospital() throws InterruptedException
    {
        driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-locality']")).clear();
        Thread.sleep(2000);
        XSSFRow r=s1.getRow(1);
        driver.findElement(By.xpath("//input[@data-qa-id='omni-searchbox-locality']")).sendKeys(r.getCell(0).getStringCellValue());
        Thread.sleep(2000);
        WebElement x=driver.findElement(By.xpath("(//div[@class='c-omni-suggestion-item'])[1]"));

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].click();", x);

        driver.findElement(By.xpath("//input[@data-input-box-id='omni-searchbox-keyword']")).click();
        driver.findElement(By.xpath("//input[@data-input-box-id='omni-searchbox-keyword']")).sendKeys(r.getCell(1).getStringCellValue());
        driver.findElement(By.xpath("//div[text()='Hospital']")).click();
    }
    @Test(priority=3)
    public void getHospitalData()
    {
        List<WebElement> rate=driver.findElements(By.xpath("//div[@class='text-1']//span[1]"));
        List<WebElement> time=driver.findElements(By.xpath("//span[@class='uv2-spacer--lg-left']"));
        List<WebElement> name=driver.findElements(By.xpath("//span[@class='text-1']"));

        List<Float> rate1=new ArrayList<Float>();
        List<String> hosRate=new ArrayList<String>();
        List<String> hosTime=new ArrayList<String>();
        List<String> hospital=new ArrayList<String>();

        for(WebElement r:rate)
        {
            float r1=Float.parseFloat(r.getText());
            rate1.add(r1);
        }
        for(WebElement h:name)
        {
            hospital.add(h.getText());
        }

        System.out.println("---The hospital name with rating >3.5--- ");
        for(int i=0;i<rate1.size();i++)
        {
            if(rate1.get(i)>=3.5)
            {
                hosRate.add(hospital.get(i));
                System.out.println(hospital.get(i));
            }
        }
        System.out.println("\n---The hospital name with 24hrs open--- ");
        int y=0;
        for(WebElement t:time) {
            y++;
            if(t.getText().equalsIgnoreCase("MON - SUN 00:00AM - 11:59PM"))
            {
                hosTime.add(name.get(y-1).getText());
                System.out.println(name.get(y-1).getText());
            }
        }

        System.out.println("\n---The hospital name with 24hrs open and ratings>3.5--- ");
        List<String> commonElements = new ArrayList<String>(hosTime);
        commonElements.retainAll(hosRate);
        XSSFRow row1=s3.createRow(0);
        XSSFCell c1=row1.createCell(0);
        c1.setCellValue("Hospitals with 24hrs open and rating>3.5");
        int row=1;
        for(String c:commonElements) {
            System.out.println(c);
            XSSFRow r=s3.createRow(row++);
            XSSFCell c2=r.createCell(0);
            c2.setCellValue(c);
        }
    }
    @Test(priority=4)
    public void getCityFromDiagnostic() throws IOException
    {
        driver.findElement(By.xpath("//span[@class='practo-logo']")).click();
        driver.findElement(By.xpath("//span[text()='Book Diagnostic Tests']")).click();
        System.out.println("\n---Top City for Diagnostic---");
        List<WebElement> cityName=driver.findElements(By.xpath("//ul[@class='u-br-rule u-marginb--std-half u-pointer u-padb--dbl o-flex o-flex__justify--between']"));
        XSSFRow row1=s4.createRow(0);
        XSSFCell c1=row1.createCell(0);
        c1.setCellValue("Top City Name for Diagnostic");
        int row=1;
        for(WebElement e:cityName)
        {
            System.out.println(e.getText());
            XSSFRow r=s4.createRow(row++);
            XSSFCell c2=r.createCell(0);
            c2.setCellValue(e.getText());
        }
        w1.write(fout2);
    }
    @Test(priority=5)
    public void fillWelnessForm() throws InterruptedException {
        driver.findElement(By.xpath("(//div[@class='u-d__inline city-selector__city u-marginb--std-half u-pointer'])[7]")).click();
        driver.findElement(By.xpath("(//span[@class='u-d-item up-triangle'])[1]")).click();
        driver.findElement(By.xpath("//a[text()='Health & Wellness Plans']")).click();

        XSSFRow r=s2.getRow(1);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
        driver.findElement(By.id("name")).sendKeys(r.getCell(0).getStringCellValue());
        driver.findElement(By.id("organizationName")).sendKeys(r.getCell(1).getStringCellValue());
        driver.findElement(By.id("contactNumber")).sendKeys(r.getCell(2).getStringCellValue());
        driver.findElement(By.id("officialEmailId")).sendKeys(r.getCell(3).getStringCellValue());
        Select select1=new Select(driver.findElement(By.id("organizationSize")));
        select1.selectByVisibleText("501-1000");
        Select select2=new Select(driver.findElement(By.id("interestedIn")));
        select2.selectByVisibleText("Taking a demo");
        Thread.sleep(3000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebElement x=driver.findElement(By.xpath("(//button[text()='Schedule a demo'])[1]")); 
        jse.executeScript("arguments[0].click();", x);
    }
    @Test(priority=6)
    public void takeInvalidScreenshot() throws IOException, InterruptedException {
        Thread.sleep(5000);
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("C:\\Users\\leora\\eclipse-workspace\\FindingHospitals\\src\\test\\java\\FindingHospitals\\InvaildMessage.png"));
        
    }
    
    public static void main(String[] args) throws Exception {

    FindingHospitals obj=new FindingHospitals();
    driverSetup();
    obj.getUrl();
    obj.gotoBangaloreHospital();
    obj.getHospitalData();
    obj.getCityFromDiagnostic();
    obj.fillWelnessForm();
    obj.takeInvalidScreenshot();
    closeBrowser();

    }
}