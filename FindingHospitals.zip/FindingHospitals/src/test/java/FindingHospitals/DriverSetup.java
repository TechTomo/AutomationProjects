package FindingHospitals;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverSetup {
	public static WebDriver driver;
    public static XSSFSheet s1,s2,s3,s4;
    public static XSSFWorkbook w,w1;
    public static FileOutputStream fout2;
    public static FileInputStream fin,fout1;
    
    @BeforeSuite
    public static WebDriver driverSetup() throws IOException
    {
        //System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\2264640\\\\Downloads\\\\chromedriver_win32\\\\chromedriver.exe");
        WebDriverManager.chromedriver().arch64().setup();
    	driver=new ChromeDriver();
        driver.manage().window().maximize();
        return driver;
    }
    @AfterSuite
    public static void closeBrowser()
    {
        driver.quit();
    }
    
}
