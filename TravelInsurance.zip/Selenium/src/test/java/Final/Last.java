package Final;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class Last {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		TestNG obj=new TestNG();
		
		List<String> suites=new ArrayList<String>();
		suites.add("C:\\Users\\2264631\\eclipse-workspace\\Selenium\\testngRun3.xml");
		
		obj.setTestSuites(suites);
		obj.run();
		

	}

}
