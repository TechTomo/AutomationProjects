package Final;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import Base.DriverSetup;
import Base.PropertiesFile;


public class Hackathon extends DriverSetup {
	
	@Test(priority=1)
	public static void Test1() throws IOException,InterruptedException
	{
		WebDriver driver = DriverSetup.search();
		String URL1 = PropertiesFile.Hackthon();
		driver.get(URL1);
		
	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
	driver.get("https://www.policybazaar.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60)) ;
	
	driver.findElement(By.xpath("/html/body/main/div[2]/section/div[7]/a/div[1]/div")).click();
	
	DriverSetup.readExcel();
    driver.findElement(By.id("country")).sendKeys(r.getCell(0).getStringCellValue());
    Thread.sleep(3000);
    driver.findElement(By.xpath("/html/body/section/div[2]/div[3]/div[2]/div/div[1]/div[2]/p[2]")).click();

    driver.findElement(By.xpath("/html/body/section/div[2]/div[3]/div[2]/div/div[2]/button")).click();
    Thread.sleep(3000);
    driver.findElement(By.xpath("/html/body/section/div[2]/div[3]/div[2]/div/div[1]/div/div[1]/div/div/input")).click();
    Thread.sleep(3000);
    driver.findElement(By.xpath("//*[text()='28']")).click();
    driver.findElement(By.xpath("//*[text()='30']")).click();
    Thread.sleep(3000);
    driver.findElement(By.xpath("//*[@id=\"prequote-wrapper\"]/div[2]/div/div[2]/button")).click();    
    
      Thread.sleep(3000);
      driver.findElement(By.xpath("//label[text()='2']")).click();  
      WebElement element=driver.findElement(By.id("divarrow_undefined"));
      Actions actions = new Actions(driver);
      actions.moveToElement(element).click().perform();
      Thread.sleep(5000);
      WebElement a=driver.findElement(By.xpath("//*[@id=\"optionBox_0_wrapper\"]/div[24]"));
      Actions b=new Actions(driver);
      b.moveToElement(a)
      .click()
      .perform();
      
      Thread.sleep(5000);
      WebElement c=driver.findElement(By.xpath("/html/body/section/div[2]/div[3]/div[2]/div/div[1]/div[2]/div[2]/div/div/div/div"));
      Actions d = new Actions(driver);
      d.moveToElement(c).click().perform();
      Thread.sleep(5000);
      WebElement e=driver.findElement(By.xpath("//*[@id=\"optionBox_1_wrapper\"]/div[23]"));
      Actions f=new Actions(driver);
      f.moveToElement(e)
      .click()
      .perform();
      
      driver.findElement(By.xpath("//*[@id=\"prequote-wrapper\"]/div[2]/div/div[2]/button")).click();
      driver.findElement(By.xpath("//*[@id=\"prequote-wrapper\"]/div[2]/div/div[1]/div/div[2]/label")).click();
      Thread.sleep(3000);
      driver.findElement(By.id("mobileNumber")).sendKeys("8102629264");
      driver.findElement(By.xpath("//*[@id=\"prequote-wrapper\"]/div[2]/div/div[2]/div/button")).click();
//      driver.findElement(By.xpath("//span[@class='text-btn']")).click();
      
      Thread.sleep(5000);
      WebElement x=driver.findElement(By.xpath("/html/body/section/div/div[2]/ul/li[2]/a"));
      Actions y = new Actions(driver);
      y.moveToElement(x).click().perform();
      driver.findElement(By.xpath("//label[@for='low']")).click();
      driver.findElement(By.xpath("//button[@class='travel_main_cta']")).click();
      
      List<String> l=new ArrayList<String>();
      List<String> g=new ArrayList<String>();
      int count=0;
      List<WebElement> name=driver.findElements(By.cssSelector("div.quotesCard__planName.hideSmall"));
      List<WebElement> price=driver.findElements(By.cssSelector("p.wrap-space"));
      for(WebElement i:name)
      {
    	  l.add(i.getText());
      }
      for(WebElement i:price)
      {
    	  g.add(i.getText());
      }
      for(count=0;count<3;count++)
      {
    	  System.out.println(l.get(count));
    	  System.out.println(g.get(count));
      }
      
	
	}
}


