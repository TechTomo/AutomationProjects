package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesFile {
	public static String URL1;
	
	public static String Hackthon() {

		try (InputStream input = 
				new FileInputStream("C:\\Users\\2264631\\eclipse-workspace\\Selenium\\src\\test\\java\\DataTables\\UrlToOpen.properties")) {
			Properties prop = new Properties();
			prop.load(input);
			 URL1 = prop.getProperty("URL1");
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return URL1;
	}
	
	
	

}
