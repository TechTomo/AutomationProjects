package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;

public class DriverSetup {
	public static WebDriver driver;
	public static Properties prop;
	public static XSSFWorkbook wb;
	public static XSSFSheet s;
	public static XSSFRow r;
	public static FileInputStream fin;
	
	@SuppressWarnings("deprecation")
	public static WebDriver search() {
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.policybazaar.com/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();

		return driver;
	}
	
	public static void readExcel() throws IOException
	{
		fin=new FileInputStream("C:\\Users\\2264631\\eclipse-workspace\\Selenium\\src\\test\\java\\Excel\\read.xlsx");
		wb=new XSSFWorkbook(fin);
		s=wb.getSheetAt(0);
		r=s.getRow(1);
		
	}
	@AfterTest
	public static void closeBrowser() {
		driver.close();
	}

}
