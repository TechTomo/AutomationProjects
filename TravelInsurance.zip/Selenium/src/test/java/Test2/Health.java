package Test2;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Base.DriverSetup;
import Base.PropertiesFile;
import Test.Test1;
import Test2.Health;

public class Health extends Test1{
	
	@Test(priority=3)
	public static void Test3() throws IOException,InterruptedException{
	String URL1 = PropertiesFile.Hackthon();
	driver.get(URL1);

    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60)) ;
	driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//*[text()='Health Insurance']")).click(); 
    Thread.sleep(5000);
	driver.findElement(By.xpath("//*[text()='Self']")).click();
	driver.findElement(By.xpath("//*[text()='Continue']")).click();
	
	Select s=new Select(driver.findElement(By.cssSelector("select.fullWidht.chkFamilyMembers")));
	s.selectByVisibleText("19 Years");
	driver.findElement(By.cssSelector("div.btnHealthStep2")).click();
	driver.findElement(By.xpath("//*[text()='Pune']")).click();
	driver.findElement(By.xpath("//*[text()='Female']")).click();
	
	DriverSetup.readExcel();
	driver.findElement(By.cssSelector("input.fullWidht.txtName")).sendKeys(r.getCell(4).getStringCellValue());
	driver.findElement(By.cssSelector("input.fullWidht.input_box.mobNumber")).sendKeys("8102629264");
	driver.findElement(By.cssSelector("div.btnHealthStep4")).click();
	driver.findElement(By.xpath("//*[text()='None of these']")).click();
	List<WebElement> name=driver.findElements(By.cssSelector("span.quotes_rvmp_card__content__plan_header__name"));
	for(WebElement i:name)
    {
  	  System.out.println(i.getText()); 
    }
	
	closeBrowser(); 
	
	
	}
}
