package Test;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import Base.DriverSetup;
import Base.PropertiesFile;
import Final.Hackathon;
import Test.Test1;


public class Test1 extends Hackathon {
	
	@Test(priority=2)
	public static void Test2() throws IOException,InterruptedException{
    String URL1 = PropertiesFile.Hackthon();
	driver.get(URL1);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60)) ;
	driver.findElement(By.xpath("/html/body/main/div[2]/section/div[4]/a/div[1]/p")).click();
	driver.findElement(By.xpath("//*[@class='btn-proceed']")).click();
	driver.findElement(By.xpath("//*[@id='spn4']")).click();
	driver.findElement(By.xpath("//span[text()='MH14']")).click();
	driver.findElement(By.xpath("//*[@class='kia']")).click();
	driver.findElement(By.xpath("//*[@class='col-sm-6 col-xs-6 ']")).click();
	driver.findElement(By.xpath("//*[@id='Petrol']")).click();
	driver.findElement(By.xpath("//li[@data-variantid='6436']")).click();
	
	DriverSetup.readExcel();
	driver.findElement(By.xpath("//*[@id='name']")).sendKeys(r.getCell(2).getStringCellValue());
	driver.findElement(By.xpath("//*[@id='email']")).sendKeys(r.getCell(3).getStringCellValue());
	
	TakesScreenshot capture = (TakesScreenshot) driver;
	File srcFile = capture.getScreenshotAs(OutputType.FILE);

		File destFile = new File(("C:\\Users\\2264631\\eclipse-workspace\\Selenium\\src\\test\\java\\Test\\")
				+ "screenshot.png");
		Files.copy(srcFile, destFile);
		

	}
}
